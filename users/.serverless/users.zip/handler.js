'use strict';

module.exports.getUsers = async (event) => {
  const users = [
    "pedro",
    "antonio",
    "afonso",
    "julia",
    "barbosa"
  ]
  
  return {
    statusCode: 200,
    body: JSON.stringify({ results: users })
  };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};
